﻿using BookShop.Models.Enums;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace BookShop
{
    using Data;

    public class StartUp
    {
        public static void Main()
        {
            using var dbContext = new BookShopContext();
            //DbInitializer.ResetDatabase(dbContext);

            //string command = Console.ReadLine()!;
            string result = CountCopiesByAuthor(dbContext);

            Console.WriteLine(result);
        }

        // -- 02
        public static string GetBooksByAgeRestriction(BookShopContext dbContext, string command)
        {
            AgeRestriction? ageRestriction = null;

            if (command != null && Enum.GetValues<AgeRestriction>().Any(ev => ev.ToString().ToLowerInvariant() == command.ToLowerInvariant()))
            {
                ageRestriction = Enum.Parse<AgeRestriction>(command, true);
            }

            if (!ageRestriction.HasValue)
            {
                return string.Empty;
            }

            IEnumerable<string> ageRestrictedBooks = dbContext.Books
                .Where(b => b.AgeRestriction == ageRestriction.Value)
                .Select(b => b.Title)
                .OrderBy(b => b)
                .ToArray();

            return string.Join(Environment.NewLine, ageRestrictedBooks);
        }

        // -- 06
        public static string GetBooksByCategory(BookShopContext dbContext, string input)
        {
            string[] categories = input
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(c => c.ToLowerInvariant())
                .ToArray();

            IEnumerable<string> bookTitlesFromCategories = dbContext.Books
                .Where(b => b.BookCategories.Any(bc => categories.Contains(bc.Category.Name.ToLower())))
                .Select(b => b.Title)
                .OrderBy(bt => bt)
                .ToArray();

            return string.Join(Environment.NewLine, bookTitlesFromCategories);
        }

        // -- 08
        public static string GetAuthorNamesEndingIn(BookShopContext dbContext, string input)
        {
            IEnumerable<string> authorFullNames = dbContext.Authors
                .Where(a => a.FirstName.EndsWith(input))
                .OrderBy(a => a.FirstName)
                .ThenBy(a => a.LastName)
                .Select(a => a.FirstName + " " + a.LastName)
                .ToArray();

            return string.Join(Environment.NewLine, authorFullNames);
        }

        // -- 12
        public static string CountCopiesByAuthor(BookShopContext dbContext)
        {
            StringBuilder sb = new();
            var authorBookCopies = dbContext.Authors
                .Select(a => new
                {
                    a.FirstName,
                    a.LastName,
                    TotalBookCopies = a.Books.Sum(b => b.Copies)
                })
                .OrderByDescending(a => a.TotalBookCopies)
                .ToArray();

            foreach (var author in authorBookCopies)
            {
                sb
                    .AppendLine($"{author.FirstName} {author.LastName} - {author.TotalBookCopies}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}