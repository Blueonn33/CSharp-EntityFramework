﻿using P01_StudentSystem.Data.Models.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace P01_StudentSystem.Data.Models.Models
{
    public class Resource
    {
        [Key]
        public int ResourceId
        {
            get; set;
        }

        [Required]
        [MaxLength(50)]
        public string Name
        {
            get;
            set;
        } = null!;

        [Required]
        public string Url
        {
            get;
            set;
        } = null!;

        public virtual ResourceType ResourceType
        {
            get; set;
        }

        [ForeignKey(nameof(Course))]
        public int CourseId
        {
            get; set;
        }

        public virtual Course Course { get; set; } = null!;
    }
}
