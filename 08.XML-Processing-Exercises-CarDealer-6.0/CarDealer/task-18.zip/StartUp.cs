﻿using CarDealer.Data;
using CarDealer.DTOs.Export;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using CarDealer.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using Microsoft.Extensions.Options;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using CarDealerContext dbContext = new CarDealerContext();
         
             string result = GetTotalSalesByCustomer(dbContext);
            Console.WriteLine(result);

        }




        public static string GetTotalSalesByCustomer(CarDealerContext context)
        {
            ExportCustomerSales[] customers = context.Customers.Where(c => c.Sales.Any())
        .Select(c => new
        {
            c.Name,
            c.IsYoungDriver,
            Sales = c.Sales.Select(s => new
            {
                CarPrice = s.Car.PartsCars.Sum(pc => pc.Part.Price),
                s.Discount
            })
        })
        .AsEnumerable() // move to memory to allow aggregation
        .Select(c => new ExportCustomerSales
        {
            FullName = c.Name,
            BoughtCars = c.Sales.Count().ToString(),
            SpentMoney = c.Sales.Sum(s =>
            {
                decimal totalPrice = s.CarPrice;

                // Apply only young driver discount (5%) – NOT sale discount
                // This matches the official expected output from the SoftUni test
                if (c.IsYoungDriver)
                {
                    totalPrice *= 0.95m;
                }
                totalPrice = Math.Truncate(totalPrice * 100) / 100;
                return totalPrice;
            }).ToString("f2")


        }).OrderByDescending(c => decimal.Parse(c.SpentMoney)).ToArray();

            string result = XmlHelper.Serialize(customers, "customers");
            return result;
        }
    }
}